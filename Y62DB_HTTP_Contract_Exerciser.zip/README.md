# Y62DB HTTP Contract Exerciser

This is a menu-driven Python client for the current REST API contract in
`rtrivgreg/aws-crud-rules-db`.

## Menu

1. `GET /rules`
2. `GET /groups`
3. `GET /rules/{ruleId}/catalog`
4. List bindings by rule OR by group
5. `GET /rules/{ruleId}/bindings/{group}/{binding}`
6. `POST /rules/{ruleId}/bindings`
7. `PUT /rules/{ruleId}/bindings/{group}/{binding}`
8. `DELETE /rules/{ruleId}/bindings/{group}/{binding}`

Choice 4 covers both list-binding contracts:

- `GET /rules/{ruleId}/bindings`
- `GET /groups/{group}/bindings`

## Sync and async

Before every request, the program asks:

`Execution mode [S]ync / [A]sync`

Both paths use the same endpoint, headers, query parameters, and JSON payload.
The client uses `httpx.Client` for synchronous calls and
`httpx.AsyncClient` for asynchronous calls.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Configure

Recommended:

```bash
export Y62DB_BASE_URL='https://YOUR-API-ID.execute-api.us-east-1.amazonaws.com/YOUR-STAGE'
export Y62DB_BEARER_TOKEN='YOUR_COGNITO_OR_JWT_TOKEN'
```

The bearer token can be omitted if the endpoint being tested does not require it.

## Run

```bash
python3 y62db_contract_client.py
```

## Important notes

- The current repository configures API Gateway methods with Cognito user-pool
  authorization, so a valid bearer token may be required against the deployed API.
- POST, PUT, and DELETE are real mutations. Point this program at a development
  endpoint unless you intentionally want to change the target data.
- PUT uses `expected_version` for optimistic locking. A stale version should
  produce HTTP 409 rather than silently overwrite another edit.
- Binding payloads are open-ended JSON, while `status` and numeric `version`
  are common required fields in the current API.
- The client deliberately does not know DynamoDB `pk`, `sk`, or GSI details.
  It exercises the REST contract only.
